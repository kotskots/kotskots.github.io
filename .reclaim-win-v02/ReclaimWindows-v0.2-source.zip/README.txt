Reclaim Windows v0.2 companion (for Reclaim Android v0.3)

1. Run ReclaimWindows-v0.2.exe and accept the Windows UAC prompt.
2. Keep the PC and Android phone on the same private Wi-Fi/LAN.
3. In Android Reclaim: Focus > Windows companion > Find Windows PC.
4. Tap your PC, enter the 6-digit pairing code shown in the Windows app, then Pair Windows.
5. When Android shows "Paired — background sync active", Work Sessions sync in both directions.

Blocking:
- League/Riot processes and Football Manager are preconfigured.
- Use ADD APP (.EXE) to add any other Windows program.
- Website categories/custom domains are blocked through the Windows hosts file during active Work Sessions.
- Closing the window minimizes to the system tray; blocking keeps running.
- Tray > Exit Reclaim fully exits and ends the session/removes Reclaim hosts entries.

Networking:
- TCP 47833: session/status API
- UDP 47834: local discovery
- Firewall rules are created for PRIVATE Windows network profiles.
- v0.3 sync is LAN-only and uses HTTP + the pairing code, so use it only on a trusted private network.
