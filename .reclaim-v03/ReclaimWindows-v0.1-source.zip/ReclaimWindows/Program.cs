using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Win32;

namespace ReclaimWindows;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        using var engine = new ReclaimEngine();
        Application.Run(new MainForm(engine));
    }
}

public sealed class ReclaimState
{
    public bool Active { get; set; }
    public long Until { get; set; }
    public string Intention { get; set; } = "";
    public long UpdatedAt { get; set; }
    public HashSet<string> Categories { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public HashSet<string> CustomDomains { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public HashSet<string> BlockedProcesses { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        "LeagueClient", "LeagueClientUx", "League of Legends", "fm", "fm24"
    };
}

public sealed class ReclaimConfig
{
    public string PairingCode { get; set; } = "";
    public string DeviceName { get; set; } = Environment.MachineName;
    public ReclaimState State { get; set; } = new();
}

public sealed class ReclaimEngine : IDisposable
{
    public const int ApiPort = 47833;
    public const int DiscoveryPort = 47834;
    private readonly string _dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Reclaim");
    private readonly string _configPath;
    private readonly object _gate = new();
    private readonly CancellationTokenSource _cts = new();
    private readonly System.Threading.Timer _enforcementTimer;
    private TcpListener? _tcp;
    private UdpClient? _udp;
    private string _lastHostsFingerprint = "";
    private bool _disposed;

    public ReclaimConfig Config { get; private set; }
    public event Action? StateChanged;

    public ReclaimEngine()
    {
        Directory.CreateDirectory(_dir);
        _configPath = Path.Combine(_dir, "config.json");
        Config = Load();
        if (Config.PairingCode.Length != 6 || !Config.PairingCode.All(char.IsDigit))
        {
            Config.PairingCode = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
            Save();
        }
        EnsureFirewallRules();
        StartServers();
        _enforcementTimer = new System.Threading.Timer(_ => Enforce(), null, 0, 900);
    }

    public ReclaimState Snapshot()
    {
        lock (_gate)
        {
            NormalizeExpiryLocked();
            return Clone(Config.State);
        }
    }

    public void StartSession(int minutes, string intention)
    {
        lock (_gate)
        {
            Config.State.Active = true;
            Config.State.Until = DateTimeOffset.UtcNow.AddMinutes(minutes).ToUnixTimeMilliseconds();
            Config.State.Intention = intention.Trim();
            Config.State.UpdatedAt = NowMs();
            SaveLocked();
        }
        Enforce();
        StateChanged?.Invoke();
    }

    public void StopSession()
    {
        lock (_gate)
        {
            Config.State.Active = false;
            Config.State.Until = 0;
            Config.State.UpdatedAt = NowMs();
            SaveLocked();
        }
        ApplyHosts(force: true);
        StateChanged?.Invoke();
    }

    public void UpdateRules(IEnumerable<string> processes, IEnumerable<string> categories, IEnumerable<string> customDomains)
    {
        lock (_gate)
        {
            Config.State.BlockedProcesses = processes.Select(NormalizeProcess).Where(x => x.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);
            Config.State.Categories = categories.Where(CategoryDomains.ContainsKey).ToHashSet(StringComparer.OrdinalIgnoreCase);
            Config.State.CustomDomains = customDomains.Select(NormalizeDomain).Where(x => x.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);
            Config.State.UpdatedAt = NowMs();
            SaveLocked();
        }
        ApplyHosts(force: true);
        StateChanged?.Invoke();
    }

    private void Enforce()
    {
        try
        {
            ReclaimState state;
            lock (_gate)
            {
                var wasActive = Config.State.Active;
                NormalizeExpiryLocked();
                if (wasActive && !Config.State.Active) SaveLocked();
                state = Clone(Config.State);
            }

            if (state.Active)
            {
                foreach (var processName in state.BlockedProcesses)
                {
                    try
                    {
                        foreach (var p in Process.GetProcessesByName(NormalizeProcess(processName)))
                        {
                            try { p.Kill(entireProcessTree: true); } catch { }
                            p.Dispose();
                        }
                    }
                    catch { }
                }
            }
            ApplyHosts();
        }
        catch { }
    }

    private void NormalizeExpiryLocked()
    {
        if (Config.State.Active && Config.State.Until <= NowMs())
        {
            Config.State.Active = false;
            Config.State.Until = 0;
            Config.State.UpdatedAt = NowMs();
        }
    }

    private void ApplyHosts(bool force = false)
    {
        ReclaimState state;
        lock (_gate) state = Clone(Config.State);
        var domains = state.Active ? ExpandDomains(state.Categories, state.CustomDomains) : new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
        var fingerprint = string.Join("|", domains);
        if (!force && fingerprint == _lastHostsFingerprint) return;

        try
        {
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", "etc", "hosts");
            var current = File.Exists(path) ? File.ReadAllLines(path).ToList() : new List<string>();
            var cleaned = new List<string>();
            bool skip = false;
            foreach (var line in current)
            {
                if (line.Trim() == "# RECLAIM BEGIN") { skip = true; continue; }
                if (line.Trim() == "# RECLAIM END") { skip = false; continue; }
                if (!skip) cleaned.Add(line);
            }
            if (domains.Count > 0)
            {
                if (cleaned.Count > 0 && cleaned[^1].Length > 0) cleaned.Add("");
                cleaned.Add("# RECLAIM BEGIN");
                foreach (var d in domains)
                {
                    cleaned.Add($"0.0.0.0 {d}");
                    cleaned.Add($":: {d}");
                }
                cleaned.Add("# RECLAIM END");
            }
            File.WriteAllLines(path, cleaned, new UTF8Encoding(false));
            _lastHostsFingerprint = fingerprint;
            RunHidden("ipconfig", "/flushdns");
        }
        catch { }
    }

    private static SortedSet<string> ExpandDomains(HashSet<string> categories, HashSet<string> custom)
    {
        var result = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var category in categories)
            if (CategoryDomains.TryGetValue(category, out var values))
                foreach (var d in values) AddDomainVariants(result, d);
        foreach (var d in custom) AddDomainVariants(result, d);
        return result;
    }

    private static void AddDomainVariants(SortedSet<string> target, string raw)
    {
        var d = NormalizeDomain(raw);
        if (d.Length == 0) return;
        target.Add(d);
        if (!d.StartsWith("www.", StringComparison.OrdinalIgnoreCase)) target.Add("www." + d);
    }

    private void StartServers()
    {
        _tcp = new TcpListener(IPAddress.Any, ApiPort);
        _tcp.Start();
        _ = Task.Run(() => TcpLoop(_cts.Token));
        _udp = new UdpClient(DiscoveryPort) { EnableBroadcast = true };
        _ = Task.Run(() => DiscoveryLoop(_cts.Token));
    }

    private async Task DiscoveryLoop(CancellationToken token)
    {
        if (_udp == null) return;
        while (!token.IsCancellationRequested)
        {
            try
            {
                var received = await _udp.ReceiveAsync(token);
                var text = Encoding.UTF8.GetString(received.Buffer);
                if (text != "RECLAIM_DISCOVER_V1") continue;
                var payload = JsonSerializer.SerializeToUtf8Bytes(new { type = "RECLAIM_WINDOWS_V1", name = Config.DeviceName, port = ApiPort });
                await _udp.SendAsync(payload, received.RemoteEndPoint, token);
            }
            catch (OperationCanceledException) { break; }
            catch { await Task.Delay(250, token).ContinueWith(_ => { }); }
        }
    }

    private async Task TcpLoop(CancellationToken token)
    {
        if (_tcp == null) return;
        while (!token.IsCancellationRequested)
        {
            try
            {
                var client = await _tcp.AcceptTcpClientAsync(token);
                _ = Task.Run(() => HandleClient(client, token), token);
            }
            catch (OperationCanceledException) { break; }
            catch { }
        }
    }

    private async Task HandleClient(TcpClient client, CancellationToken token)
    {
        using (client)
        using (var stream = client.GetStream())
        {
            try
            {
                var req = await ReadHttpRequest(stream, token);
                if (req == null) return;
                if (!req.Headers.TryGetValue("X-Reclaim-Code", out var code) || code.Trim() != Config.PairingCode)
                {
                    await WriteJson(stream, 401, new { error = "Invalid pairing code" }, token);
                    return;
                }

                if (req.Method == "GET" && req.Path == "/api/status")
                {
                    await WriteJson(stream, 200, StatePayload(Snapshot()), token);
                    return;
                }

                if (req.Method == "POST" && req.Path == "/api/session")
                {
                    using var doc = JsonDocument.Parse(req.Body.Length == 0 ? "{}" : req.Body);
                    var root = doc.RootElement;
                    var incomingUpdated = root.TryGetProperty("updatedAt", out var u) ? u.GetInt64() : 0;
                    lock (_gate)
                    {
                        NormalizeExpiryLocked();
                        if (incomingUpdated >= Config.State.UpdatedAt)
                        {
                            Config.State.Active = root.TryGetProperty("active", out var a) && a.GetBoolean();
                            Config.State.Until = root.TryGetProperty("until", out var until) ? until.GetInt64() : 0;
                            Config.State.Intention = root.TryGetProperty("intention", out var intent) ? intent.GetString() ?? "" : "";
                            Config.State.UpdatedAt = incomingUpdated;
                            Config.State.Categories = ReadStringSet(root, "categories", CategoryDomains.ContainsKey);
                            Config.State.CustomDomains = ReadStringSet(root, "customDomains", _ => true).Select(NormalizeDomain).Where(x => x.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);
                            SaveLocked();
                        }
                    }
                    Enforce();
                    StateChanged?.Invoke();
                    await WriteJson(stream, 200, StatePayload(Snapshot()), token);
                    return;
                }

                await WriteJson(stream, 404, new { error = "Not found" }, token);
            }
            catch
            {
                try { await WriteJson(stream, 400, new { error = "Bad request" }, token); } catch { }
            }
        }
    }

    private static HashSet<string> ReadStringSet(JsonElement root, string name, Func<string, bool> accept)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!root.TryGetProperty(name, out var arr) || arr.ValueKind != JsonValueKind.Array) return set;
        foreach (var item in arr.EnumerateArray())
        {
            var value = item.GetString() ?? "";
            if (accept(value)) set.Add(value);
        }
        return set;
    }

    private static object StatePayload(ReclaimState state) => new
    {
        active = state.Active && state.Until > NowMs(),
        until = state.Until,
        intention = state.Intention,
        updatedAt = state.UpdatedAt,
        categories = state.Categories.OrderBy(x => x).ToArray(),
        customDomains = state.CustomDomains.OrderBy(x => x).ToArray()
    };

    private sealed record HttpRequest(string Method, string Path, Dictionary<string, string> Headers, string Body);

    private static async Task<HttpRequest?> ReadHttpRequest(NetworkStream stream, CancellationToken token)
    {
        using var ms = new MemoryStream();
        var one = new byte[1];
        int matched = 0;
        byte[] delimiter = "\r\n\r\n"u8.ToArray();
        while (ms.Length < 64 * 1024)
        {
            int n = await stream.ReadAsync(one, token);
            if (n <= 0) return null;
            ms.WriteByte(one[0]);
            if (one[0] == delimiter[matched])
            {
                matched++;
                if (matched == 4) break;
            }
            else matched = one[0] == delimiter[0] ? 1 : 0;
        }
        var headerText = Encoding.UTF8.GetString(ms.ToArray());
        var lines = headerText.Split("\r\n", StringSplitOptions.None);
        var first = lines[0].Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (first.Length < 2) return null;
        var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in lines.Skip(1))
        {
            var idx = line.IndexOf(':');
            if (idx > 0) headers[line[..idx].Trim()] = line[(idx + 1)..].Trim();
        }
        int length = headers.TryGetValue("Content-Length", out var cl) && int.TryParse(cl, out var parsed) ? Math.Clamp(parsed, 0, 1024 * 1024) : 0;
        var body = new byte[length];
        int read = 0;
        while (read < length)
        {
            int n = await stream.ReadAsync(body.AsMemory(read, length - read), token);
            if (n <= 0) break;
            read += n;
        }
        return new HttpRequest(first[0].ToUpperInvariant(), first[1], headers, Encoding.UTF8.GetString(body, 0, read));
    }

    private static async Task WriteJson(NetworkStream stream, int status, object payload, CancellationToken token)
    {
        var body = JsonSerializer.SerializeToUtf8Bytes(payload);
        var reason = status switch { 200 => "OK", 400 => "Bad Request", 401 => "Unauthorized", 404 => "Not Found", _ => "OK" };
        var head = Encoding.ASCII.GetBytes($"HTTP/1.1 {status} {reason}\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: {body.Length}\r\nConnection: close\r\n\r\n");
        await stream.WriteAsync(head, token);
        await stream.WriteAsync(body, token);
    }

    private ReclaimConfig Load()
    {
        try
        {
            if (!File.Exists(_configPath)) return new ReclaimConfig();
            return JsonSerializer.Deserialize<ReclaimConfig>(File.ReadAllText(_configPath), JsonOptions) ?? new ReclaimConfig();
        }
        catch { return new ReclaimConfig(); }
    }

    private void Save() { lock (_gate) SaveLocked(); }
    private void SaveLocked() => File.WriteAllText(_configPath, JsonSerializer.Serialize(Config, JsonOptions));

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter() }
    };

    private static ReclaimState Clone(ReclaimState s) => new()
    {
        Active = s.Active,
        Until = s.Until,
        Intention = s.Intention,
        UpdatedAt = s.UpdatedAt,
        Categories = new HashSet<string>(s.Categories, StringComparer.OrdinalIgnoreCase),
        CustomDomains = new HashSet<string>(s.CustomDomains, StringComparer.OrdinalIgnoreCase),
        BlockedProcesses = new HashSet<string>(s.BlockedProcesses, StringComparer.OrdinalIgnoreCase)
    };

    public static string NormalizeProcess(string p) => Path.GetFileNameWithoutExtension(p.Trim());
    public static string NormalizeDomain(string raw)
    {
        var d = raw.Trim().ToLowerInvariant();
        d = d.Replace("https://", "").Replace("http://", "");
        if (d.StartsWith("www.")) d = d[4..];
        foreach (var sep in new[] { '/', '?', '#' }) { var i = d.IndexOf(sep); if (i >= 0) d = d[..i]; }
        return d.Trim('.');
    }

    private static long NowMs() => DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

    private static void RunHidden(string file, string args)
    {
        try { Process.Start(new ProcessStartInfo(file, args) { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden })?.WaitForExit(3000); } catch { }
    }

    private static void EnsureFirewallRules()
    {
        RunHidden("netsh", $"advfirewall firewall delete rule name=\"Reclaim Sync TCP\"");
        RunHidden("netsh", $"advfirewall firewall add rule name=\"Reclaim Sync TCP\" dir=in action=allow protocol=TCP localport={ApiPort} profile=private");
        RunHidden("netsh", $"advfirewall firewall delete rule name=\"Reclaim Discovery UDP\"");
        RunHidden("netsh", $"advfirewall firewall add rule name=\"Reclaim Discovery UDP\" dir=in action=allow protocol=UDP localport={DiscoveryPort} profile=private");
    }

    public static string LocalIp()
    {
        try
        {
            return NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up && n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a.Address))
                .Select(a => a.Address.ToString())
                .FirstOrDefault(ip => ip.StartsWith("192.168.") || ip.StartsWith("10.") || ip.StartsWith("172.")) ?? "Unknown";
        }
        catch { return "Unknown"; }
    }

    public static readonly Dictionary<string, string[]> CategoryDomains = new(StringComparer.OrdinalIgnoreCase)
    {
        ["SOCIAL"] = new[] { "facebook.com", "instagram.com", "threads.net", "x.com", "twitter.com", "reddit.com", "tumblr.com", "pinterest.com", "snapchat.com", "linkedin.com" },
        ["SHORT_VIDEO"] = new[] { "tiktok.com", "musical.ly", "youtube.com", "youtu.be", "instagram.com", "facebook.com" },
        ["STREAMING"] = new[] { "netflix.com", "disneyplus.com", "primevideo.com", "hulu.com", "twitch.tv", "max.com", "hbomax.com", "crunchyroll.com" },
        ["GAMING"] = new[] { "steampowered.com", "steamcommunity.com", "epicgames.com", "riotgames.com", "leagueoflegends.com", "op.gg", "u.gg", "metatft.com" },
        ["SHOPPING"] = new[] { "amazon.com", "amazon.de", "ebay.com", "aliexpress.com", "temu.com", "shein.com", "skroutz.gr", "bestprice.gr" },
        ["GAMBLING"] = new[] { "bet365.com", "stake.com", "betsson.com", "bwin.com", "novibet.gr", "stoiximan.gr", "opap.gr", "pokerstars.com" },
        ["ADULT"] = new[] { "pornhub.com", "xvideos.com", "xnxx.com", "redtube.com", "youporn.com", "xhamster.com", "onlyfans.com", "fansly.com", "chaturbate.com" }
    };

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _cts.Cancel();
        _enforcementTimer.Dispose();
        _tcp?.Stop();
        _udp?.Dispose();
        _cts.Dispose();
    }
}

public sealed class MainForm : Form
{
    private readonly ReclaimEngine _engine;
    private readonly Label _status = new();
    private readonly Label _countdown = new();
    private readonly TextBox _intention = new();
    private readonly NumericUpDown _minutes = new();
    private readonly Button _startStop = new();
    private readonly TextBox _processes = new();
    private readonly TextBox _domains = new();
    private readonly Dictionary<string, CheckBox> _categoryChecks = new(StringComparer.OrdinalIgnoreCase);
    private readonly NotifyIcon _tray = new();
    private readonly System.Windows.Forms.Timer _uiTimer = new();
    private bool _reallyExit;

    public MainForm(ReclaimEngine engine)
    {
        _engine = engine;
        Text = "Reclaim — Windows";
        Width = 720;
        Height = 820;
        MinimumSize = new Size(650, 700);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(15, 18, 22);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 10f);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(20), AutoScroll = true, ColumnCount = 1, RowCount = 20 };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        Controls.Add(root);

        root.Controls.Add(LabelOf("RECLAIM WINDOWS", 22, FontStyle.Bold));
        root.Controls.Add(LabelOf($"This PC: {engine.Config.DeviceName}   •   IP: {ReclaimEngine.LocalIp()}   •   Port: {ReclaimEngine.ApiPort}"));
        root.Controls.Add(LabelOf($"Pairing code: {engine.Config.PairingCode}", 17, FontStyle.Bold, Color.FromArgb(169, 245, 200)));
        root.Controls.Add(LabelOf("Enter this 6-digit code in Reclaim on Android. Keep both devices on the same private Wi-Fi for v0.3 sync.", 9, FontStyle.Regular, Color.Silver));

        _status.AutoSize = true; _status.Margin = new Padding(0, 18, 0, 2); root.Controls.Add(_status);
        _countdown.AutoSize = true; _countdown.Font = new Font("Segoe UI", 22, FontStyle.Bold); root.Controls.Add(_countdown);

        _intention.PlaceholderText = "What are you working on?"; _intention.Dock = DockStyle.Top; root.Controls.Add(_intention);
        var sessionRow = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, WrapContents = false, Margin = new Padding(0, 8, 0, 15) };
        _minutes.Minimum = 5; _minutes.Maximum = 480; _minutes.Value = 90; _minutes.Width = 90;
        sessionRow.Controls.Add(_minutes); sessionRow.Controls.Add(LabelOf("minutes", 10));
        _startStop.Text = "START WORK SESSION"; _startStop.AutoSize = true; _startStop.Padding = new Padding(12, 5, 12, 5); _startStop.Click += (_, _) => ToggleSession();
        sessionRow.Controls.Add(_startStop); root.Controls.Add(sessionRow);

        root.Controls.Add(LabelOf("Blocked Windows apps", 15, FontStyle.Bold));
        root.Controls.Add(LabelOf("One process name per line. .exe is optional. League + Football Manager defaults are already included.", 9, FontStyle.Regular, Color.Silver));
        _processes.Multiline = true; _processes.Height = 115; _processes.ScrollBars = ScrollBars.Vertical; _processes.Dock = DockStyle.Top; root.Controls.Add(_processes);

        root.Controls.Add(LabelOf("Website categories", 15, FontStyle.Bold));
        var categories = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        foreach (var (key, label) in new[]
        {
            ("SOCIAL", "Social media"), ("SHORT_VIDEO", "Short-form video"), ("STREAMING", "Streaming"),
            ("GAMING", "Gaming"), ("SHOPPING", "Shopping"), ("GAMBLING", "Gambling & betting"), ("ADULT", "Adult / NSFW")
        })
        {
            var cb = new CheckBox { Text = label, AutoSize = true, Tag = key, ForeColor = ForeColor };
            _categoryChecks[key] = cb; categories.Controls.Add(cb);
        }
        root.Controls.Add(categories);

        root.Controls.Add(LabelOf("Custom blocked domains", 15, FontStyle.Bold));
        root.Controls.Add(LabelOf("One domain per line, e.g. reddit.com", 9, FontStyle.Regular, Color.Silver));
        _domains.Multiline = true; _domains.Height = 90; _domains.ScrollBars = ScrollBars.Vertical; _domains.Dock = DockStyle.Top; root.Controls.Add(_domains);

        var buttons = new FlowLayoutPanel { AutoSize = true, Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 10) };
        var save = new Button { Text = "SAVE BLOCKING RULES", AutoSize = true, Padding = new Padding(10, 4, 10, 4) }; save.Click += (_, _) => SaveRules();
        var test = new Button { Text = "OPEN RECLAIM DATA FOLDER", AutoSize = true, Padding = new Padding(10, 4, 10, 4) }; test.Click += (_, _) => Process.Start("explorer.exe", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Reclaim"));
        buttons.Controls.Add(save); buttons.Controls.Add(test); root.Controls.Add(buttons);

        root.Controls.Add(LabelOf("During an active session Reclaim checks blocked apps every ~1 second and adds temporary system-wide domain rules to the Windows hosts file. Closing this window minimizes to the tray so enforcement continues.", 9, FontStyle.Regular, Color.Silver));

        _tray.Icon = SystemIcons.Shield;
        _tray.Text = "Reclaim Windows";
        _tray.Visible = true;
        _tray.DoubleClick += (_, _) => RestoreWindow();
        var trayMenu = new ContextMenuStrip();
        trayMenu.Items.Add("Open Reclaim", null, (_, _) => RestoreWindow());
        trayMenu.Items.Add("End Work Session", null, (_, _) => _engine.StopSession());
        trayMenu.Items.Add("Exit Reclaim", null, (_, _) => { _engine.StopSession(); _reallyExit = true; _tray.Visible = false; Close(); });
        _tray.ContextMenuStrip = trayMenu;

        FormClosing += (_, e) => { if (!_reallyExit) { e.Cancel = true; Hide(); _tray.ShowBalloonTip(1200, "Reclaim is still running", "App and website blocking continue in the background.", ToolTipIcon.Info); } };
        _engine.StateChanged += RefreshFromEngineSafe;
        _uiTimer.Interval = 1000; _uiTimer.Tick += (_, _) => RefreshStatusOnly(); _uiTimer.Start();
        LoadFromEngine();
    }

    private static Label LabelOf(string text, float size = 10, FontStyle style = FontStyle.Regular, Color? color = null) => new()
    {
        Text = text, AutoSize = true, MaximumSize = new Size(640, 0), Font = new Font("Segoe UI", size, style), ForeColor = color ?? Color.WhiteSmoke, Margin = new Padding(0, 4, 0, 4)
    };

    private void ToggleSession()
    {
        var state = _engine.Snapshot();
        if (state.Active) _engine.StopSession();
        else { SaveRules(); _engine.StartSession((int)_minutes.Value, _intention.Text); }
    }

    private void SaveRules()
    {
        var procs = _processes.Lines.Select(x => x.Trim()).Where(x => x.Length > 0);
        var cats = _categoryChecks.Where(kv => kv.Value.Checked).Select(kv => kv.Key);
        var domains = _domains.Lines.Select(x => x.Trim()).Where(x => x.Length > 0);
        _engine.UpdateRules(procs, cats, domains);
    }

    private void LoadFromEngine()
    {
        var s = _engine.Snapshot();
        _intention.Text = s.Intention;
        _processes.Lines = s.BlockedProcesses.OrderBy(x => x).ToArray();
        _domains.Lines = s.CustomDomains.OrderBy(x => x).ToArray();
        foreach (var kv in _categoryChecks) kv.Value.Checked = s.Categories.Contains(kv.Key);
        RefreshStatusOnly();
    }

    private void RefreshFromEngineSafe()
    {
        if (IsDisposed) return;
        if (InvokeRequired) { BeginInvoke((Action)LoadFromEngine); return; }
        LoadFromEngine();
    }

    private void RefreshStatusOnly()
    {
        var s = _engine.Snapshot();
        var active = s.Active && s.Until > DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        _status.Text = active ? $"WORK SESSION ACTIVE  •  {s.Intention}" : "READY";
        _status.ForeColor = active ? Color.FromArgb(169, 245, 200) : Color.Silver;
        if (active)
        {
            var left = TimeSpan.FromMilliseconds(Math.Max(0, s.Until - DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()));
            _countdown.Text = $"{(int)left.TotalHours:00}:{left.Minutes:00}:{left.Seconds:00}";
            _startStop.Text = "END WORK SESSION";
        }
        else
        {
            _countdown.Text = "00:00:00";
            _startStop.Text = "START WORK SESSION";
        }
    }

    private void RestoreWindow() { Show(); WindowState = FormWindowState.Normal; Activate(); }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _uiTimer.Dispose();
            _tray.Dispose();
            _engine.StateChanged -= RefreshFromEngineSafe;
        }
        base.Dispose(disposing);
    }
}
