Reclaim Windows v0.1 companion (for Reclaim Android v0.3)

- Run ReclaimWindows.exe and accept the Windows UAC prompt.
- Windows Firewall rules are added for PRIVATE networks only: TCP 47833 and UDP 47834.
- The app shows a 6-digit pairing code. Enter it in Android Reclaim > Focus > Windows companion.
- Default blocked process names include League Client / League of Legends and Football Manager.
- During an active session, selected process names are terminated and selected domains are placed temporarily in the Windows hosts file.
- Closing the main window minimizes Reclaim to the notification tray. Use tray > Exit Reclaim to fully exit; that action ends the session and removes Reclaim's hosts block.
- v0.3 sync is LAN-only and HTTP + pairing-code authenticated. Use on a trusted private Wi-Fi/LAN.
